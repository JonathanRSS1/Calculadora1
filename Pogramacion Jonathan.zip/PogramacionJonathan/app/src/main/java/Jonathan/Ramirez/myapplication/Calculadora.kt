package Jonathan.Ramirez.myapplication

class Calculadora {

    fun sumar (num1: Double,num2: Double) : Double
    {
       val resultado = num1 + num2
       return resultado
    }

    fun restar (num1: Int,num2: Int): Int
    {

        val resultado1 = num1 - num2
        return resultado1
    }

    fun multiplicar(num1: Int,num2: Int):Int
    {
        val resultado2 = num1 * num2
        return resultado2
    }

    fun dividir(num1: Int,num2: Int):Int
    {
        val resultado = num1 / num2
        return resultado

    }


}