package Jonathan.Ramirez.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }

        //-Mandar a llamar a todos los elementos

        val txtnum1 = findViewById<EditText>(R.id.txtNum1)
        val txtnum2 = findViewById<EditText>(R.id.txtNum2)
        val btnSumar = findViewById<Button>(R.id.btnSumar)
        val btnRestar = findViewById<Button>(R.id.btnRestar)
        val btnMultiplicar = findViewById<Button>(R.id.btnMultiplicar)
        val btnDividir = findViewById<Button>(R.id.btnDividir)

        val txtResulado = findViewById<TextView>(R.id.txtResultado)




        //cREO UN OBJETO DE LA CLASE CALCULADORA
        //para que con ese objeto, si llmar al metodo de sumar

        val objCalculadora = Calculadora()

        //2-Programar los elementos

        btnSumar.setOnClickListener {

           val result = objCalculadora.sumar(txtnum1.text.toString().toDouble(),txtnum2.text.toString().toDouble())
            Toast.makeText(this,"Este es el resultado $result",Toast.LENGTH_LONG).show()

            txtResulado.text = "El resultado es $result"

        }

        btnRestar.setOnClickListener {

            val result = objCalculadora.restar(txtnum1.text.toString().toInt(),txtnum2.text.toString().toInt())
            Toast.makeText(this,"Este es el resultado $result",Toast.LENGTH_LONG).show()

            txtResulado.text = "El resultado es $result"

        }


        btnMultiplicar.setOnClickListener {

            val result = objCalculadora.multiplicar(txtnum1.text.toString().toInt(),txtnum2.text.toString().toInt())
            Toast.makeText(this,"Este es el resultado $result",Toast.LENGTH_LONG).show()

            txtResulado.text = "El resultado es $result"

        }

        btnDividir.setOnClickListener {

            val result = objCalculadora.dividir(txtnum1.text.toString().toInt(),txtnum2.text.toString().toInt())
            Toast.makeText(this,"Este es el resultado $result",Toast.LENGTH_LONG).show()

            txtResulado.text = "El resultado es $result"

        }








    }
}