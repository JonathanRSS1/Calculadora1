class Calculadora {
}